rootProject.name = "ToggleWidget"
include(":app")
